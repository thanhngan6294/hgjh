#ifndef MSGEDITOR_H
#define MSGEDITOR_H

#include <QDialog>
#include "ui_msgeditor.h"
namespace Ui {
class MsgEditor;
}

class MsgEditor : public QDialog, Ui_MsgEditor
{
    Q_OBJECT

public:
    explicit MsgEditor(QWidget *parent = 0);
    ~MsgEditor();
signals:
    void editedMsg(bool save);


private:
};

#endif // MSGEDITOR_H
