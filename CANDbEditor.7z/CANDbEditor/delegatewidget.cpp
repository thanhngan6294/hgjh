#include "delegatewidget.h"
#include<QSpinBox>
DelegateWidget::DelegateWidget()
{
}
